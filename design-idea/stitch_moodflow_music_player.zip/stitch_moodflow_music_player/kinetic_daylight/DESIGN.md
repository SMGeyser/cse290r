---
name: Kinetic Daylight
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#414938'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#727a66'
  outline-variant: '#c1cab3'
  surface-tint: '#3b6a00'
  primary: '#3a6700'
  on-primary: '#ffffff'
  primary-container: '#4a8300'
  on-primary-container: '#f9ffeb'
  inverse-primary: '#92da47'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006387'
  on-tertiary: '#ffffff'
  tertiary-container: '#007da9'
  on-tertiary-container: '#fcfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#acf760'
  primary-fixed-dim: '#92da47'
  on-primary-fixed: '#0e2000'
  on-primary-fixed-variant: '#2b5000'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Syne
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 60px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Syne
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Syne
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Syne
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Syne
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  metric-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  metric-xl-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-cadence athleticism merged with clean modernism. Built for runners moving through fluctuating daylight, glare, and rapid motion, the visual language prioritizes immediate legibility, kinetic energy, and precision tactile controls.

The aesthetic fuses contemporary Swiss-style layout precision with high-energy sportswear ergonomics:
- **Atmosphere:** Sunlit, airy, and hyper-focused. Off-white canvas tones keep screens soft on dilated eyes, while pure white elevated cards provide crisp visual grouping.
- **Energy:** A tuned electric citron-lime accent brings velocity and pulse without visual fatigue or unreadable contrast against light grounds.
- **Physicality:** Large tactile touch targets, weighted typography for glanceable metrics (pace, cadence, heart rate, BPM sync), and subtle atmospheric shadows engineered to communicate clickable controls on the move.

## Colors

The color system delivers high sunlight legibility while avoiding eye strain during long-distance movement.

- **Primary (`#5B9E00`):** Electric Volt Lime, calibrated specifically for contrast ratios exceeding 4.5:1 on white and off-white backgrounds for key interactive highlights, progress meters, and dynamic BPM lock states.
- **Secondary (`#0F172A`):** Deep Slate Ink for ultra-crisp typography, primary action buttons, and critical telemetry readings.
- **Tertiary (`#38BDF8`):** Aerobic Sky Cyan, reserved for secondary track indicators, heart-rate pacing differentials, and audio waveform secondary sweeps.
- **Neutral (`#64748B`):** Muted Slate for structural dividers, inactive track states, metadata labels, and ambient telemetry units.
- **Surfaces:**
  - Base canvas: `#FAFAFA`
  - Elevated surfaces & modular cards: `#FFFFFF`
  - Recessed interactive tracks / scrubber wells: `#F1F3F5`
  - Hairline borders: `#E2E8F0`

## Typography

The pairing combines the sculptural, forward-moving geometry of **Syne** for titles, cadence statuses, and track identifiers, with the rock-solid legibility of **Inter** for live telemetry and analytical parameters.

- Use uppercase styling exclusively with `label-sm` when designating measurement tags (e.g., `BPM`, `PACE`, `KM/H`, `SYNC`).
- Metric numerical fields must rely on tabular lining figures within Inter to avoid layout jitter during real-time running feed updates.
- Keep text color locked to `#0F172A` for primary readouts and `#334155` for contextual secondary text. Avoid low-contrast grays below `#64748B` to guarantee sunlight visibility.

## Layout & Spacing

The structural layout relies on an 8pt fluid grid that preserves direct single-hand thumb reaches across handheld sessions.

- **Breakpoints:**
  - Phone: `< 640px` (4-column fluid layout, `margin`: 1rem, dynamic thumb zones anchored along the bottom 40% of the viewport).
  - Tablet: `640px – 1024px` (8-column fluid layout, `margin`: 2rem).
  - Desktop / Dashboard: `> 1024px` (12-column grid capped at 1280px max-width, `margin`: 3rem).
- Spacing rhythm enforces expansive touch targets during high heart-rate conditions: minimum target bounding boxes are 48×48px with standard spacing between adjacent controls set at `space-md` (1rem).

## Elevation & Depth

Visual hierarchy uses clean surface stacking coupled with diffuse ambient shadows to separate actionable running controls from passive metric surfaces:

- **Level 0 (Canvas):** Flat base `#FAFAFA`.
- **Level 1 (Telemetry Cards & Panels):** Pure white `#FFFFFF` paired with a crisp border (`1px solid #E2E8F0`) and an ambient, sunlight-tolerant shadow: `0 2px 8px -2px rgba(15, 23, 42, 0.04), 0 1px 3px -1px rgba(15, 23, 42, 0.06)`.
- **Level 2 (Active Controls / Floating Playback Dock):** Lifted surfaces using `0 12px 24px -6px rgba(15, 23, 42, 0.08), 0 4px 8px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Engaged State / Cadence Sync Aura):** Tinted soft glow for elements synchronized with real-time stride: `0 0 24px 0 rgba(91, 158, 0, 0.28)`.

## Shapes

The shape system adopts a rounded ergonomic geometry (`roundedness: 2`, where base components use 0.5rem/8px, medium cards use 1rem/16px, and container modals use 1.5rem/24px).

Interactive chips, scrubbing thumbs, and quick-trigger buttons shift intentionally toward full capsules (`rounded-full`) to simulate physical sports hardware toggles and tactile watch interfaces.

## Components

- **Buttons:**
  - *Primary Kinetic:* Deep slate background (`#0F172A`), white text, bold font-weight, full capsule radius (`9999px`), minimum height of 52px for high-movement accuracy.
  - *Accent Pulse (Cadence Lock):* Electric volt lime (`#5B9E00`), deep slate text (`#0F172A`), tactile scale press feedback (`active:scale-95`).
  - *Ghost / Secondary:* `#FFFFFF` fill with `1px solid #E2E8F0` border and slate text.
- **Cards:**
  - Built on `#FFFFFF` surfaces with subtle `1px solid #E2E8F0` borders and 16px corner radii.
  - Metrics cards feature strict separation: upper label in `label-sm` neutral uppercase, metric value in bold `metric-xl-mobile`, and footer indicator displaying delta comparisons.
- **Chips & Filters:**
  - Pill-shaped (`rounded-full`), padded `space-xs` vertically and `space-md` horizontally.
  - Unselected: `#F1F3F5` surface with `#334155` text.
  - Selected: `#0F172A` with `#FFFFFF` text, or `#5B9E00` tint when locking BPM target ranges.
- **Running Telemetry Bar & Audio Scrubbers:**
  - Base track: Recessed `#F1F3F5`, 8px track height with rounded caps.
  - Active fill: `#5B9E00` solid bar with optional animated gradient pulse.
  - Scrubber head: 24px solid white disc with a `2px solid #5B9E00` rim and Level 2 elevation for immediate grabability.
- **Inputs & Search:**
  - Tall fields (48px height) on `#FFFFFF`, surrounded by `#E2E8F0` outlines.
  - Focus state swaps border color cleanly to `#5B9E00` with an accompanying subtle volt shadow ring.
- **Checkboxes & Radios:**
  - 20×20px dimensions with 6px border-radius (checkbox) or full circle (radio).
  - Selected state fills with `#0F172A` framing a white checkmark or center pin, highlighted with an optional `#5B9E00` border focus ring.